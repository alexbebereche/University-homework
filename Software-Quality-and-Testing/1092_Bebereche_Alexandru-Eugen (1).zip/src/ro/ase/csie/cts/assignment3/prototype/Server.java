package ro.ase.csie.cts.assignment3.prototype;

public class Server implements ServerInterface {

	String ipAddress;
	int port;
	int maxConnections;

	@Override
	public String getIpAddress() {
		return this.ipAddress;
	}

	@Override
	public int getPort() {
		return this.port;
	}

	@Override
	public int getMaxConnections() {
		return this.maxConnections;
	}

	@Override
	public boolean connect() {
		return false;
	}

	@Override
	public boolean disconnect() {
		return false;
	}

	private Server() {

	}

	public Server(String ipAddress, int port, int maxConnections) {
		super();
		this.ipAddress = ipAddress;
		this.port = port;
		this.maxConnections = maxConnections;

		//some processing...
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {

		Server copy = new Server();

		copy.ipAddress = this.ipAddress;
		copy.maxConnections = this.maxConnections;
		copy.port = this.port;

		return copy;

	}

}
