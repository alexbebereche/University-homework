package ro.ase.csie.cts.assignment3.singleton;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestSingleton {

	static Server server1;
	static Server server2;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		server1 = Server.getServer("10.0.0.2:4321", 1, 2);
		server2 = Server.getServer("10.0.0.2:4322", 1, 2);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Ignore
	@Test
	public void test() {
		fail("Not yet implemented");
	}

	@Test
	public void testSingleton() {
		
		assertSame("They are the same", server1, server2);
	}
}
