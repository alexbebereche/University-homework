package ro.ase.csie.cts.assignment3.prototype;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestPrototype {

	static Server server1;
	static Server server2;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		server1 = new Server("10.0.0.2:4321", 1, 2);
		server2 = (Server) server1.clone();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Ignore
	@Test
	public void test() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrototypeDeepCopy() {

		assertNotSame("They are not the same", server1, server2);
	}

	@Test
	public void testPrototypeValues() {

		assertEquals("ips are the same", server1.ipAddress, server2.ipAddress);
		assertEquals("connections are the same", server1.maxConnections, server2.maxConnections);
		assertEquals("ports are the same", server1.port, server2.port);
	}

}
