package ro.ase.csie.cts.assignment3.simpleFactory;

public class ServerFactory {

	public static ServerInterface getServer(ServerType type, String address) {

		ServerInterface server = null;

		switch (type) {
		case LOCAL:
			server = new Server(address, 8080, 10);
			break;
		default:
			throw new UnsupportedOperationException("Type not covered");
		}

		return server;

	}

}
