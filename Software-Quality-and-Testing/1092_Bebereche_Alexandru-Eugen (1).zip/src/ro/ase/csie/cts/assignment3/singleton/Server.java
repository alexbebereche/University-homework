package ro.ase.csie.cts.assignment3.singleton;

public class Server implements ServerInterface {

	String ipAddress;
	int port;
	int maxConnections;

	private static Server server = null;

	@Override
	public String getIpAddress() {
		return this.ipAddress;
	}

	@Override
	public int getPort() {
		return this.port;
	}

	@Override
	public int getMaxConnections() {
		return this.maxConnections;
	}

	@Override
	public boolean connect() {
		return false;
	}

	@Override
	public boolean disconnect() {
		return false;
	}

	private Server(String ipAddress, int port, int maxConnections) {
		super();
		this.ipAddress = ipAddress;
		this.port = port;
		this.maxConnections = maxConnections;
	}

	public static Server getServer(String ipAddress, int port, int maxConnections) {
		if (Server.server == null) {
			server = new Server(ipAddress, port, maxConnections);
		}

		return Server.server;
	}

}
