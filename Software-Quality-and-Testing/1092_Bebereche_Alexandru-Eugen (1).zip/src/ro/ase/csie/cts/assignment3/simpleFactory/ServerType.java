package ro.ase.csie.cts.assignment3.simpleFactory;

public enum ServerType {

	LOCAL
}
