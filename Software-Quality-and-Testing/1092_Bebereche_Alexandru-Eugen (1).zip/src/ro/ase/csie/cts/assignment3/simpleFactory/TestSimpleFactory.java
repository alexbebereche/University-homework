package ro.ase.csie.cts.assignment3.simpleFactory;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestSimpleFactory {

	static Server server;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		server = new Server("local", 8080, 10);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Ignore
	@Test
	public void test() {
		fail("Not yet implemented");
	}

	@Test
	public void testSimpleFactory() {

		ServerInterface serverFactory = ServerFactory.getServer(ServerType.LOCAL, "local");

		assertEquals("same address", server.ipAddress, serverFactory.getIpAddress());
		assertEquals("same port", server.port, serverFactory.getPort());
		assertEquals("same max connections", server.maxConnections, serverFactory.getMaxConnections());

	}

	@Test
	public void testSimpleFactoryNotEqual() {

		ServerInterface serverFactory = ServerFactory.getServer(ServerType.LOCAL, "local2");

		assertNotEquals("diff address", server.ipAddress, serverFactory.getIpAddress());
		assertNotEquals("diff port", server.port, serverFactory.getPort() + 1);
		assertNotEquals("diff max connections", server.maxConnections, serverFactory.getMaxConnections() + 1);

	}

}
