package ro.ase.csie.cts.assignment2.exceptions;

public class InvalidDaysActiveException extends Exception{

}
