package ro.ase.csie.cts.assignment2;

public interface AccountInterface {
	public static final float BROKER_FEE = 0.0125f;
	public static final double MIN_VALUE_LOAN = 100;
	public static final double MAX_VALUE_LOAN = 1_000_000;
	public static final int DAYS_IN_A_YEAR = 365;
	
	public double getMonthlyRate();
}
