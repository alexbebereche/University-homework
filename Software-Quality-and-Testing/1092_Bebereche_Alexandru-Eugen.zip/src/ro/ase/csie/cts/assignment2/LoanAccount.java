package ro.ase.csie.cts.assignment2;

import ro.ase.csie.cts.assignment2.exceptions.InvalidDaysActiveException;
import ro.ase.csie.cts.assignment2.exceptions.InvalidLoanValueException;
import ro.ase.csie.cts.assignment2.exceptions.InvalidRateException;

public class LoanAccount implements AccountInterface {

	private double loanValue;
	private double rate;
	private int daysActive;
	AccountType accountType;

	public LoanAccount(double loanValue, double rate, AccountType accountType) throws Exception {
		setLoanValue(loanValue);
		setRate(rate);
		this.accountType = accountType;
	}

	public double getLoanValue() {
		return this.loanValue;
	}

	public double getRate() {
		return this.rate;
	}

	public int getDaysActive() {
		return daysActive;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setDaysActive(int daysActive) throws InvalidDaysActiveException {
		if(daysActive < 0 || daysActive > DAYS_IN_A_YEAR) {
			throw new InvalidDaysActiveException();
		}
		this.daysActive = daysActive;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public void setRate(double rate) throws InvalidRateException {
		if (rate < 0) {
			throw new InvalidRateException();
		}
		this.rate = rate;
	}

	public void setLoanValue(double loanValue) throws InvalidLoanValueException {
		if (loanValue < MIN_VALUE_LOAN || loanValue > MAX_VALUE_LOAN)
			throw new InvalidLoanValueException();
		else {
			this.loanValue = loanValue;
		}
	}

	public static double getAccountDaysActivePercentage(LoanAccount account) {
		return account.daysActive / DAYS_IN_A_YEAR;
	}

	public static double getInterestRateOnDaysActive(LoanAccount account) {
		return Math.pow(account.rate, getAccountDaysActivePercentage(account));
	}

	public static double getInterest(LoanAccount account) {
		return account.loanValue * getInterestRateOnDaysActive(account);
	}

	public static double getAccountFeeWithoutBrokerFee(LoanAccount account) {
		return getInterest(account) - account.loanValue;
	}

	public static double getAccountFeeWithBrokerFee(LoanAccount account) {
		return BROKER_FEE * getAccountFeeWithoutBrokerFee(account);
	}

	public static double getTotalFeeValueForPremiumAndSuperPremiumAccount(LoanAccount[] accounts) {
		double totalFee = 0.0;
		for (LoanAccount account : accounts) {
			if (account.accountType == AccountType.PREMIUM || account.accountType == AccountType.SUPER_PREMIUM) {
				totalFee += getAccountFeeWithBrokerFee(account);
			}
		}
		return totalFee;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();

		builder.append("Loan: ")
		.append(this.loanValue)
		.append("; rate: ")
		.append(this.rate)
		.append("; days active: ")
		.append(this.daysActive)
		.append("; Type: ")
		.append(this.accountType);

		return builder.toString();
	}

	@Override
	public double getMonthlyRate() {
		return this.loanValue * this.rate;
	}
}