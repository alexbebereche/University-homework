package ro.ase.csie.cts.assignment2.exceptions;

public class InvalidLoanValueException extends Exception {
	
	public InvalidLoanValueException() {
	}
}
