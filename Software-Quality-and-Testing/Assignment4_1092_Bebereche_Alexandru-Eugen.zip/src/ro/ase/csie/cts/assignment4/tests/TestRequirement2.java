package ro.ase.csie.cts.assignment4.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import ro.ase.csie.cts.assignment4.classes.Product;
import ro.ase.csie.cts.assignment4.exceptions.InvalidIndexException;
import ro.ase.csie.cts.assignment4.exceptions.InvalidLimitException;
import ro.ase.csie.cts.assignment4.exceptions.InvalidSoldItemsException;

public class TestRequirement2 {

	// test fixture
	public static final String NAME = "Child Toy";
	public static final float PRICE = 20f;
	public static ArrayList<Integer> SOLD_ITEMS;

	Product mainProduct;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		SOLD_ITEMS = new ArrayList<Integer>();

		SOLD_ITEMS.add(100);
		SOLD_ITEMS.add(200);
		SOLD_ITEMS.add(300);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		mainProduct = new Product(NAME, PRICE, SOLD_ITEMS);
	}

	@After
	public void tearDown() throws Exception {
	}
	
	

	@Test
	public void testAddWeekRightValues() throws InvalidSoldItemsException, InvalidIndexException {

		mainProduct.addWeek(400);
		
		int expected = 400;
		int computed = mainProduct.getSoldItems(mainProduct.getNoSoldItems() - 1);
		
		assertEquals("They are the same", expected, computed);
		

	}
	
	@Test
	public void testGetSoldItemsRightValues() throws InvalidSoldItemsException, InvalidIndexException {
		
		int expected = 100;
		int computed = mainProduct.getSoldItems(0);
		
		assertEquals("They are the same", expected, computed);
		

	}
	
	@Test
	public void testGetNoWeeksAboveLimitRightValues() throws InvalidSoldItemsException, InvalidIndexException, InvalidLimitException {
		
		int expected = 2;
		int computed = mainProduct.getNoWeeksAboveLimit(101);
		
		assertEquals("They are the same", expected, computed);
		

	}
	
	
	
	// RANGE
	@Test(expected = InvalidSoldItemsException.class)
	public void testAddWeekRange() throws InvalidSoldItemsException {

		mainProduct.addWeek(1001);

	}
	
	@Test(expected = InvalidIndexException.class)
	public void testGetSoldItemsRange() throws InvalidSoldItemsException, InvalidIndexException {

		mainProduct.getSoldItems(-1);

	}
	
	@Test(expected = InvalidLimitException.class)
	public void testGetNoWeeksAboveLimitRange() throws InvalidSoldItemsException, InvalidLimitException {

		mainProduct.getNoWeeksAboveLimit(2000);

	}

}
