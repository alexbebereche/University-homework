package ro.ase.csie.cts.assignment4.classes;

import java.util.ArrayList;

import ro.ase.csie.cts.assignment4.exceptions.InvalidIndexException;
import ro.ase.csie.cts.assignment4.exceptions.InvalidLimitException;
import ro.ase.csie.cts.assignment4.exceptions.InvalidNameException;
import ro.ase.csie.cts.assignment4.exceptions.InvalidPriceException;
import ro.ase.csie.cts.assignment4.exceptions.InvalidSoldItemsException;

/*
 * 
 * DISCLAIMER
 * Most of the given methods are implemented with bugs
 * Cele mai multe dintre metodele date au bug-uri 
 * 
 * 
 * SPECS
 * 
 * name - between 5 and 200 alpha-numeric chars (no special chars)
 * price - between [0.01, 100000)
 * soldItems - between [0, 1000]
 * 
 * 
 */


public class Product {
	public static float MIN_PRICE = 0.01f;
	public static float MAX_PRICE = 100000f;
	
	private String name;
	private float price;
	private ArrayList<Integer> weeklySoldItems; // number of items sold each week

	public Product(String name, float price) throws InvalidNameException, InvalidPriceException {
		// name = name; //mistake
//		this.name = name;
//		this.price = price;

		setName(name);
		setPrice(price);

		weeklySoldItems = new ArrayList<Integer>();
	}

	public Product(String name, float price, ArrayList<Integer> soldItems)
			throws InvalidNameException, InvalidPriceException {

		setName(name);
		setPrice(price);

		this.weeklySoldItems = new ArrayList<Integer>();
		for (Integer n : soldItems)
			this.weeklySoldItems.add(n);
	}

	public void setPrice(float price) throws InvalidPriceException {
		if (price < 0.01 || price > 100000f) {
			throw new InvalidPriceException();
		}

		this.price = price;
	}

	public void setName(String name) throws InvalidNameException {
		if (name.length() < 5 || name.length() > 200) { // assume its inclusive...
			throw new InvalidNameException();
		}

		this.name = name;
	}

	public void setSales(ArrayList<Integer> soldItems) throws InvalidSoldItemsException {
		if (soldItems == null) {
			throw new InvalidSoldItemsException();
		}
		
		this.weeklySoldItems = (ArrayList<Integer>) soldItems.clone();
		

	}

	public String getName() {
		return this.name;
	}

	public float getPrice() {
		return this.price;
	}

	public void addWeek(int soldItems) throws InvalidSoldItemsException {
		if(soldItems < 0 || soldItems > 1000) {
			throw new InvalidSoldItemsException();
		}
		this.weeklySoldItems.add(soldItems);
	}

	public int getSoldItems(int i) throws InvalidSoldItemsException, InvalidIndexException {
		
		if(i < 0 || i >= this.getNoSoldItems()) {
			throw new InvalidIndexException();
		}
		
		if(this.weeklySoldItems == null) {
			throw new InvalidSoldItemsException();
		}
		return weeklySoldItems.get(i);
	}

	
	/*
	 * 
	 * determines the number of weeks with sales above the given limit determina
	 * numarul de saptamani in care au fost vandute un numar de produse peste limita
	 * data
	 * 
	 */
	public int getNoWeeksAboveLimit(int minLimit) throws InvalidSoldItemsException, InvalidLimitException {
		
		if(this.weeklySoldItems == null) {
			throw new InvalidSoldItemsException();
		}
		
		if(minLimit < 0 || minLimit > 1000) {
			throw new InvalidLimitException();
		}
		
		int noWeeks = 0;
		for (int n : this.weeklySoldItems)
			if (n >= minLimit)
				noWeeks++;
//		noWeeks++;
		return noWeeks;
	}

	/*
	 * 
	 * determines the percentage (%) of weeks with sales under the given limit from
	 * total number of weeks determina procentul saptamanilor (din total saptamani)
	 * care au avut vanzari sub limita data
	 * 
	 */
	public int getPercentOfBadWeeks(int minLimit) {
		float m = 0;
		for (Integer n : weeklySoldItems)
			if (n > minLimit)
				m += n;

		return (int) (100 * m / this.weeklySoldItems.size());
	}

	/*
	 * 
	 * 
	 * determines the index of the weeks with maximum sales (multiple weeks can have
	 * maximum sales) determina indexul saptamanilor cu vanzari maxime (mai multe
	 * saptamani pot avea vanzari la nivel maxim)
	 * 
	 * 
	 */

	public ArrayList<Integer> getWeeksIndexWithMaxSales() {
		ArrayList<Integer> maxWeeks = new ArrayList<>();
		int max = this.weeklySoldItems.get(0);

		for (int i = 0; i < this.weeklySoldItems.size(); i++)
			if (this.weeklySoldItems.get(i) > max)
				maxWeeks.add(i);

		return maxWeeks;
	}

	@Override
	public String toString() {
		String output = this.name + " weekly sales: ";
		for (Integer n : weeklySoldItems)
			output += n + " ";
		return output;
	}
	
	public int getNoSoldItems() {
		return this.weeklySoldItems.size();
	}
}