package ro.ase.csie.cts.assignment4.exceptions;

public class InvalidNameException extends Exception {

}
