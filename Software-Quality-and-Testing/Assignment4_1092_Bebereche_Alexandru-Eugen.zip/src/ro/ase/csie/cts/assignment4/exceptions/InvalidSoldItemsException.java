package ro.ase.csie.cts.assignment4.exceptions;

public class InvalidSoldItemsException extends Exception{

}
