package Bebereche.AlexandruEugen.g1092.Decorator;

//generally, just a wrapper, does nothing...
public abstract class AbstractDecorator extends AbstractTask{

	AbstractTask decoratedObject;

	public AbstractDecorator(AbstractTask decoratedObject) {
		super(decoratedObject.name, decoratedObject.estimatedTimeInHours);
		// TODO Auto-generated constructor stub
	}

	//callback
	@Override
	public void whatToDo() {
		this.decoratedObject.whatToDo();
	}

	@Override
	public void increaseTime(float hours) {
		this.decoratedObject.increaseTime(hours);
		
	}

	@Override
	public void isFinished() {
		this.decoratedObject.isFinished();
		
	}

	
}
