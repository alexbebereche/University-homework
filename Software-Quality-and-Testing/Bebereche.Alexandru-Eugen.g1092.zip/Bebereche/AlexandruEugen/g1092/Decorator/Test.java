package Bebereche.AlexandruEugen.g1092.Decorator;

public class Test {

	public static void main(String[] args) {
		
		AbstractTask taskDecorator = new SquareOneTask("study for cts exam", 5, false);
		taskDecorator.whatToDo();
		
		AbstractTask tiringTask = new StopDecorator(taskDecorator);
		tiringTask.whatToDo();
	}

}
