package Bebereche.AlexandruEugen.g1092.Decorator;

public enum Priority {
	LOW,
	MEDIUM,
	HIGH
}
