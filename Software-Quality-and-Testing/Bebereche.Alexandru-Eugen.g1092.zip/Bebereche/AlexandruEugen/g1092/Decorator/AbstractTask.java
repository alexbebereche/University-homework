package Bebereche.AlexandruEugen.g1092.Decorator;

public abstract class AbstractTask {

	protected String name;
	protected float estimatedTimeInHours;
	
	public AbstractTask(String name, float estimatedTimeInHours) {
		super();
		this.name = name;
		this.estimatedTimeInHours = estimatedTimeInHours;
	}
	
	public abstract void whatToDo();
	public abstract void increaseTime(float hours);
	public abstract void isFinished();
}
