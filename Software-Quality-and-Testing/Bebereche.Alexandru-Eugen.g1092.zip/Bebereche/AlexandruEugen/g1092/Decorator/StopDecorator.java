package Bebereche.AlexandruEugen.g1092.Decorator;

public class StopDecorator extends AbstractDecorator {

	
	public StopDecorator(AbstractTask decoratedObject) {
		super(decoratedObject);
	}

	@Override
	public void whatToDo() {
		System.out.println("You are probably tired and should stop working");
	}

	
}
