package Bebereche.AlexandruEugen.g1092.Singleton;

public class TestSingleton {

	public static void main(String[] args) {
		
		DbConnection c1 = DbConnection.getConnection();
		DbConnection c2 = DbConnection.getConnection();
		
		if (c1 == c2) {
			System.out.println("They are referencing the same object");
		}

	}

}
