package Bebereche.AlexandruEugen.g1092.Singleton;

public class DbConnection {

	private static DbConnection dbConnection = null;
	
	private DbConnection() {
		System.out.println("Db connection created");
	}
	
	public static DbConnection getConnection() {
		if(DbConnection.dbConnection == null) {
			dbConnection = new DbConnection();
		}
		
		return DbConnection.dbConnection;
	}
}
