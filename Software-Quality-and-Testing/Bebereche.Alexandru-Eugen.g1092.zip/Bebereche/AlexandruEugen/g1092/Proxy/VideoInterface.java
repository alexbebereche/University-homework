package Bebereche.AlexandruEugen.g1092.Proxy;

public interface VideoInterface {
	public abstract void displayVideo();
}
