package Bebereche.AlexandruEugen.g1092.Proxy;

public class Video implements VideoInterface{

	private String file = null;

	@Override
	public void displayVideo() {
		System.out.println("video displayed: " + file);
	}
	
	public Video(final String video) {
		file = video;
		loadVideo();
	}
	
	public void loadVideo(){
		System.out.println(this.file + " Video load");
	}

	
}
