package Bebereche.AlexandruEugen.g1092.Proxy;

public class TestProxy {

	public static void main(String[] args) {
		
		VideoInterface video1 = new Video("video.mp4");
		
		video1.displayVideo();
		video1.displayVideo();

	
		final VideoInterface V1 = new VideoProxy("v1", "youtube.com/asda");
		final VideoInterface V2 = new VideoProxy("v2", "youtube.com/asasdfs");
	
	
		V1.displayVideo();
		V2.displayVideo();
	}

}
