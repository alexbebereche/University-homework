package Bebereche.AlexandruEugen.g1092.Proxy;

public class VideoProxy implements VideoInterface{
	
	private Video real = null;
	private String file = null;
	private String connection = null;
	
	public VideoProxy(final String video, final String connection) {
		this.file = video;
		this.connection = connection;
	}

	@Override
	public void displayVideo() {
		if(isEnoughMemory(this.file) && checkInternetConnection(this.connection)) {
			if(real == null) {
				real = new Video(file);
			}
			
			real.displayVideo();
		}
	}
	
	boolean isEnoughMemory(String file) {
		System.out.println("checking memory");
		return true;
	}
	
	boolean checkInternetConnection(String connection) {
		System.out.println("checking connection");
		return true;
	}
	
	
}
