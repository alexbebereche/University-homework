package Bebereche.AlexandruEugen.g1092.Adapter;

public interface SimpleTaskInterface {

	public abstract void getAdvice();
	public abstract void addOvertime(float time);
	
	public abstract String getName();
	public abstract float getTime();
}
