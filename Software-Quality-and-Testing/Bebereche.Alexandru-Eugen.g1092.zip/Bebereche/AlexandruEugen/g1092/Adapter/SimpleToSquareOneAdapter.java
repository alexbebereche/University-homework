package Bebereche.AlexandruEugen.g1092.Adapter;

public class SimpleToSquareOneAdapter extends AbstractTask {

	SimpleTaskInterface simpleTask = null;

	
	public SimpleToSquareOneAdapter(SimpleTaskInterface simpleTask) {
		super(simpleTask.getName(), simpleTask.getTime());
		this.simpleTask = simpleTask;
	}

	//wrapper class, need a reference

	@Override
	public void whatToDo() {
		this.simpleTask.getAdvice();
	}

	@Override 
	public void increaseTime(float hours) {
		this.simpleTask.addOvertime(hours);
	}

	//this was added
	@Override
	public void isFinished() {
		System.out.println("the task: " + this.simpleTask.getName() + " is finished");
	}
	
	
}
