package Bebereche.AlexandruEugen.g1092.Adapter;

public class SimpleTask implements SimpleTaskInterface {

	String name;
	float duration;
	
	
	public SimpleTask(String name, float duration) {
		super();
		this.name = name;
		this.duration = duration;
	}

	@Override
	public void getAdvice() {
		System.out.println("consider your priorities");
	}

	@Override
	public void addOvertime(float time) {
		System.out.println(String.format("The time became %5.3f, from %5.3f", this.duration + time, this.duration));
		this.duration += time;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public float getTime() {
		return this.duration;
	}

	
}
