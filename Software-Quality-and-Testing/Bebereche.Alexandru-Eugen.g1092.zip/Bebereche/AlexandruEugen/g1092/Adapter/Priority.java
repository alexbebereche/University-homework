package Bebereche.AlexandruEugen.g1092.Adapter;

public enum Priority {
	LOW,
	MEDIUM,
	HIGH
}
