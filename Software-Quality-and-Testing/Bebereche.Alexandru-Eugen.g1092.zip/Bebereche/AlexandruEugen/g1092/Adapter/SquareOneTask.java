package Bebereche.AlexandruEugen.g1092.Adapter;

public class SquareOneTask extends AbstractTask {

	Priority priority;
	boolean isFinished;

	public SquareOneTask(String name, float estimatedTimeInHours, boolean isFinished) {
		super(name, estimatedTimeInHours);
		this.isFinished = isFinished;
		this.priority = Priority.HIGH;
		
	}

	
	@Override
	public void whatToDo() {
		if(this.isFinished) {
			System.out.println("Task is done, you can do something else");
		}
		else {
			System.out.println("keep working on: " + this.name);
		}
	}

	@Override
	public void increaseTime(float hours) {
		System.out.println(String.format("%s increased with %5.2f hours", this.name, hours));
		this.estimatedTimeInHours += hours;
	}
	
	public void isFinished() {
		System.out.println("the task: " + this.name + " is finished");
	}

}
