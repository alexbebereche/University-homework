package Bebereche.AlexandruEugen.g1092.Adapter;

import java.util.ArrayList;

public class TestAdapter {

	public static void main(String[] args) {
		
		AbstractTask task = new SquareOneTask("do homework", 1f, false);
		task.whatToDo();
		task.increaseTime(2f);
		
		//dont forget to decide what adapts to what
		//want to use a simple task as a square one task
		
		SimpleTaskInterface simpleTask = new SimpleTask("Clean desk", 0.25f);
		simpleTask.getAdvice();
		simpleTask.addOvertime(0.1f);
		
		
		ArrayList<AbstractTask> tasks = new ArrayList<AbstractTask>();
		tasks.add(task);
		
		//how can i add simpleTask?
//		tasks.add(simpleTask); // nope
		SimpleToSquareOneAdapter simpleToSquareAdapter = new SimpleToSquareOneAdapter(simpleTask);
		tasks.add(simpleToSquareAdapter);
		
		System.out.println("-------------");
		for(AbstractTask abstractTask : tasks) {
			abstractTask.whatToDo();
			abstractTask.isFinished();
		}
	}

}
