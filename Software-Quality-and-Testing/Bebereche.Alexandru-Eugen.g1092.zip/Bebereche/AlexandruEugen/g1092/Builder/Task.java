package Bebereche.AlexandruEugen.g1092.Builder;

public class Task {

	String name;
	Priority priority;
	boolean isCompleted;
	float estimatedTimeInHours;
	
	//removed empty constr
	private Task() {
	
	}
	
	public Task(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "Task [name=" + name + ", priority=" + priority + ", isCompleted=" + isCompleted
				+ ", estimatedTimeInHours=" + estimatedTimeInHours + "]";
	}


	public static class TaskBuilder{
		
		Task task = null;
		
		// dont need to know the priority, if it's completed, or the estimated time
		public TaskBuilder(String name) {
			this.task = new Task();
			this.task.name = name;
			
			//all i need, the rest with setters
		}
		
		
		public TaskBuilder isCompleted() {
			this.task.isCompleted = true;
			return this;
		}
		
		public TaskBuilder setPriority(Priority priority) {
			this.task.priority = priority;
			return this;
		}
		
		public TaskBuilder setEstimatedTime(float time) {
			this.task.estimatedTimeInHours = time;
			return this;
		}
		
		public Task build() {
			return this.task;
		}
		
		
		
	}
	
}
