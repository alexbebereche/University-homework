package Bebereche.AlexandruEugen.g1092.Builder;

public enum Priority {
	LOW,
	MEDIUM,
	HIGH
}
