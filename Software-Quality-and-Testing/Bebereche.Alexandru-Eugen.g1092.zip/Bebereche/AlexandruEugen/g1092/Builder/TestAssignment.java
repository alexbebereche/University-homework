package Bebereche.AlexandruEugen.g1092.Builder;
import Bebereche.AlexandruEugen.g1092.Prototype.TaskPrototype;

public class TestAssignment {

	public static void main(String[] args) {
		
		//builder
		
		Task task = new Task.TaskBuilder("Clean room")
				.setPriority(Priority.LOW)
				.setEstimatedTime(0.5f) // careful, its float, not double...
				.build();
		
		System.out.println(task.toString());
		
		
		//prototype
		
		
		
		
	}

}
