package Bebereche.AlexandruEugen.g1092.Prototype;

public enum Priority {
	LOW,
	MEDIUM,
	HIGH
}
