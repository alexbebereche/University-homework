package Bebereche.AlexandruEugen.g1092.Prototype;

public class TestAssignment {
	
	public static void main(String[] args) throws CloneNotSupportedException {
		TaskPrototype task = new TaskPrototype("Clean room", Priority.LOW, false, 0.5f);
		
		TaskPrototype task2 = (TaskPrototype) task.clone();
		
		System.out.println(task.toString());
		System.out.println(task2.toString());
		
	}
}
