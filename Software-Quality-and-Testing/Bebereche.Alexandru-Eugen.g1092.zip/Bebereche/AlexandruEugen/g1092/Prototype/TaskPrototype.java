package Bebereche.AlexandruEugen.g1092.Prototype;

public class TaskPrototype {

	String name;
	Priority priority;
	boolean isCompleted;
	float estimatedTimeInHours;
	

	public TaskPrototype(String name, Priority priority, boolean isCompleted, float estimatedTimeInHours) {
		super();
		this.name = name;
		this.priority = priority;
		this.isCompleted = isCompleted;
		this.estimatedTimeInHours = estimatedTimeInHours;
		
		System.out.println("processing....");
	}

	//remove empty constr
	private TaskPrototype() {
		// TODO Auto-generated constructor stub
	}


	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		TaskPrototype copy = new TaskPrototype();
		
		copy.name = this.name;
		copy.priority = this.priority;
		copy.isCompleted = this.isCompleted;
		copy.estimatedTimeInHours = this.estimatedTimeInHours;
		
		return copy;
	}

	@Override
	public String toString() {
		return "Task [name=" + name + ", priority=" + priority + ", isCompleted=" + isCompleted
				+ ", estimatedTimeInHours=" + estimatedTimeInHours + "]";
	}
	
}
