package Bebereche.AlexandruEugen.g1092.Factory;

public class SquareTwoTask extends AbstractTask{
	
	public SquareTwoTask(String name, boolean isCompleted, float estimatedTime) {
		this.name = name;
		this.isCompleted = isCompleted;
		this.estimatedTimeInHours = estimatedTime;
	}

	@Override
	public void whatToDo() {
		System.out.println("You should decide if you do it or not, schedule a time");
	}

}
