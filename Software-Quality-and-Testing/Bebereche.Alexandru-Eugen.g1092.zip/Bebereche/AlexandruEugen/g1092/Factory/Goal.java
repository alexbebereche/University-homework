package Bebereche.AlexandruEugen.g1092.Factory;

public class Goal {

	String name;
	AbstractTask task;
	
	public Goal(String name) {
		this.name = name;
	}

	public AbstractTask getTask() {
		return task;
	}
	
	public void setTask(AbstractTask task) {
		this.task = task;
	}

	@Override
	public String toString() {
		return "goal: " + this.name + " task:" + task.name + "|" + task.estimatedTimeInHours;
	}
	
	
}
