package Bebereche.AlexandruEugen.g1092.Factory;

public enum Priority {
	ZERO,
	LOW,
	MEDIUM,
	HIGH
}
