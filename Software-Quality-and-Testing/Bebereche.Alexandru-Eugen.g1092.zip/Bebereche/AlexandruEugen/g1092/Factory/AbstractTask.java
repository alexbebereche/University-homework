package Bebereche.AlexandruEugen.g1092.Factory;

public abstract class AbstractTask {

	protected String name;
	protected boolean isCompleted;
	protected float estimatedTimeInHours;
	
	public abstract void whatToDo();
}
