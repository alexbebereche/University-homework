package Bebereche.AlexandruEugen.g1092.Factory;

public class TestAssignment {

	public static void main(String[] args) {
		
		Goal goal = new Goal("Pass exam");
		
		//---------------------------------
//		goal.setTask(new SquareOneTask("Work on 3 examples", false, 2f));
//		System.out.println(goal.toString());
//
//		goal.setTask(new SquareThreeTask("sleep", false, 8f));
//		System.out.println(goal.toString());

		//-------------------------------
		AbstractTask study = TasksFactory.getTask(Priority.HIGH, "Go to tutoring", 2f);
		goal.setTask(study);
		System.out.println(goal.toString());

	
		AbstractTask task1 = TasksFactory.getTask(Priority.MEDIUM, "Watch tutorials", 1f);
		task1.whatToDo();

		AbstractTask task2 = TasksFactory.getTask(Priority.LOW, "Read book", 4f);
		task2.whatToDo();
		
	}

}
