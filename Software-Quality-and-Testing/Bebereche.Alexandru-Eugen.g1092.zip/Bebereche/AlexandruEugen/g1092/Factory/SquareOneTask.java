package Bebereche.AlexandruEugen.g1092.Factory;

public class SquareOneTask extends AbstractTask{
	
	public SquareOneTask(String name, boolean isCompleted, float estimatedTime) {
		this.name = name;
		this.isCompleted = isCompleted;
		this.estimatedTimeInHours = estimatedTime;
	}

	@Override
	public void whatToDo() {
		System.out.println("You should do this task now!");
	}

}
