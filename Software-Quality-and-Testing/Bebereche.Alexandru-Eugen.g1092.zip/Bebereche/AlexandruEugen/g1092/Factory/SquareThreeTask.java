package Bebereche.AlexandruEugen.g1092.Factory;

public class SquareThreeTask extends AbstractTask {

	public SquareThreeTask(String name, boolean isCompleted, float estimatedTime) {
		this.name = name;
		this.isCompleted = isCompleted;
		this.estimatedTimeInHours = estimatedTime;
	}

	@Override
	public void whatToDo() {
		System.out.println("You should try to delegate this task!");
	}
}
