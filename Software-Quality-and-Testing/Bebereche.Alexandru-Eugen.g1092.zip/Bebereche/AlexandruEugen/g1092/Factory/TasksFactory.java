package Bebereche.AlexandruEugen.g1092.Factory;

public class TasksFactory {

	public static AbstractTask getTask(Priority priority, String name, float duration) {
		
		AbstractTask task = null;
		
		switch(priority) {
		case HIGH:
			task = new SquareOneTask(name, false, duration);
			break;
		case MEDIUM:
			task = new SquareTwoTask(name, false, duration);
			break;
		case LOW:
			task = new SquareThreeTask(name, false, duration);
			break;
		case ZERO:
			task = new SquareFourTask(name, false, duration);
			break;
		default:
			throw new UnsupportedOperationException("New priority type was added...");
		}
		
		return task;
		
	}
}
